<?php

$databaseHost = 'localhost';
$databaseName = 'phpcrud';
$databaseUsername = 'root';
$databasePassword = 'root';
try{
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 }
catch(mysqli_sql_exception $exception){
    echo "Connection error: " . $exception->getMessage();}
?>
