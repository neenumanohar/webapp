<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\widgets\ActiveForm;


$this->title = 'ITP Media ';
?>

<div class="site-index">
    <h3 style = "color: #337ab7;">User Details</h3>
	<div class="body-content">

	<ul class="list-group">
  		<li class="list-group-item d-flex justify-content-between align-items-center">
			<?php echo $res->name; ?>
		</li>
  		<li class="list-group-item d-flex justify-content-between align-items-center">
			<?php echo $res->email ?>
  		</li>
  		<li class="list-group-item d-flex justify-content-between align-items-center">
			<?php echo $res->passport?>
        </li>
  		<li class="list-group-item d-flex justify-content-between align-items-center">
			<?php echo $res->phone?>
        </li>
  		<li class="list-group-item d-flex justify-content-between align-items-center">
			<?php echo $res->address?>
        </li>


    </ul>
	<div class="row">

		<a href=<?php echo yii::$app->homeUrl; ?> class="btn btn-primary">Go Back </a>

  
 	 </div>
	</div>
</div>
