<?php

use yii\db\Migration;

/**
 * Handles the creation of table `registration`.
 */
class m180619_160517_create_registration_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('registration', [
            'id' => $this->primaryKey(),
            'name' => $this->char(50),
            'passport' => $this->string(50),
            'email' => $this->string(100)->notNull()->unique(),
            'phone' => $this->integer(),
            'address' => $this->text(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('registration');
    }
}
