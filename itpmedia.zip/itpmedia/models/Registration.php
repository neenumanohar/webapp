<?php
    namespace app\models;
	use yii\db\ActiveRecord;
	class Registration extends ActiveRecord
	{

		private $name;
		private $passport;
		private $email;
		private $phone;
		private $address;


		public function rules(){
			return[
				[['name','passport','email','phone','address'],'required']
			];
		}
	}

?>